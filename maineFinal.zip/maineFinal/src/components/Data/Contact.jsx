import React from "react";

import FullTable from "./Table/WagesTable";
import PopTable from "./Table/PopTable";
import InvestmentTable from "./Table/Investment";
import Scrollspy from 'react-scrollspy'

import "./scrollStyles.css";

import {PlotEIA} from './plotEIA'
import {PlotExportsWood} from './plotExportsWood'
import {PlotExportsPaper} from './plotExportsPaper'
import {PlotHSExports} from './hsExports'

import {PlotInventory} from "./plotInventory";
import {PlotHarvest} from "./plotHarvest";


export const Contact = () => {



  return (
    <div className="contact">
        <div className="primary-page">

            <section id="section-1" style={{ paddingTop: '60px',
                marginTop: '-40px'}}>
                <div className={"inventoryPlot"}>
                    <h1>Maine Forest Inventory</h1>
                    <PlotInventory />
                </div>
            </section>

            <section id="section-2" style={{ paddingTop: '60px',
                marginTop: '-40px'}}>
                <div className={"harvestPlot"}>
                    <h1>Maine Forest Harvests</h1>
                    <PlotHarvest />
                </div>
            </section>



            <section id="section-3" style={{ paddingTop: '60px',
                marginTop: '-40px'}}>
                <div className={"exportHSPlots"}>
                    <PlotHSExports
                    />
                </div>
            </section>

            <section id="section-4" style={{ paddingTop: '60px',
                marginTop: '-40px'}}>
                <h1 style={{display: 'block'}} >International Exports from Maine by NACIS Code</h1>
                <div className={"exportPlots"} style={{ display: 'flex'}}>
                    <PlotExportsWood
                    />
                    <PlotExportsPaper
                    />
                </div>
            </section>

            <section id="section-5" style={{ paddingTop: '60px',
                marginTop: '-40px'}}>
                <div className="plotEIAContainer">
                    <h1>Energy Costs</h1>
                    <PlotEIA
                    />
                </div>
            </section>

            <section id="section-6" style={{ paddingTop: '60px', paddingBottom: '10rem',
                marginTop: '-40px'}}>
                <div>
                    <h1>Investment Incentives</h1>
                    <h5>Workforce Training Assistance:</h5>
                    <h6 style={{textIndent:"1em"}}><a target={"_blank"} href="https://www.mccs.me.edu/workforce-training/train-my-workforce/maine-quality-centers/" rel="noopener noreferrer">Maine Quality Centers Program</a></h6>




                    <h6 style={{textIndent:"1em"}}>Maine Apprenticeship Program</h6>
                    <h6 style={{textIndent:"1em"}}>Safety and Education Training Program</h6>
                    <h6 style={{textIndent:"1em"}}>Manufacturing Extension Partnership</h6>
                    <h6 style={{textIndent:"1em"}}>Manufacturers Association of Maine</h6>
                    <h6 style={{textIndent:"1em"}}>Community Development Block Grant</h6>
                    <h5>Financial and Tax:</h5>
                    <h6 style={{textIndent:"1em"}}>Pine Tree Development Zones</h6>
                    <h6 style={{textIndent:"1em"}}>Employment Tax Increment Financing</h6>
                    <h6 style={{textIndent:"1em"}}>Technology Tax Credits</h6>
                    <h6 style={{textIndent:"1em"}}>Business Equipment Tax Exemption</h6>
                    <h6 style={{textIndent:"1em"}}>Maine Seed Capital Tax Credit</h6>
                    <h6 style={{textIndent:"1em"}}>New Markets Capital Investment Credit</h6>
                    <h6 style={{textIndent:"1em"}}>Maine Venture Fund</h6>
                    <h6 style={{textIndent:"1em"}}>Opportunity Zones</h6>
                    <h5>Maine Technology R&D Development Grants and Loans:</h5>
                    <h6 style={{textIndent:"1em"}}>Tech-starts Grants</h6>
                    <h6 style={{textIndent:"1em"}}>Seed Grants</h6>
                    <h6 style={{textIndent:"1em"}}>Development Awards</h6>
                    <h6 style={{textIndent:"1em"}}>Accelerator Grant</h6>
                    <h6 style={{textIndent:"1em"}}>Equity Capital</h6>
                    <h6 style={{textIndent:"1em"}}>Cluster Initiative</h6>
                    <h5>Technical and Operational Support:</h5>
                    <h6 style={{textIndent:"1em"}}>Office of Innovation and Assistance</h6>
                    <h6 style={{textIndent:"1em"}}>Small Business Technical Assistance Program</h6>
                    <h6 style={{textIndent:"1em"}}>Coordinated Environmental Permitting</h6>
                    <h6 style={{textIndent:"1em"}}>Efficiency Maine</h6>
                    <h6 style={{textIndent:"1em"}}>Maine International Trade Center</h6>
                </div>
            </section>

            <section id="section-7" style={{ paddingTop: '60px',
                marginTop: '-40px'}}>
                <div>
                    <h1>Employment and Earnings</h1>
                    <FullTable />
                </div>
            </section>

            <section id="section-8"  style={{ paddingTop: '60px', paddingBottom: '10rem',
                marginTop: '-40px'}}>
                <div>
                    <h1>Population</h1>
                    <PopTable />
                </div>
            </section>

            <section id="section-9"  style={{ paddingTop: '60px', paddingBottom: '10rem',
                marginTop: '-40px'}}>
                <div>
                    <h1>Additional References</h1>
                    <h4>Building Trends: Mass Timber - <a target={"_blank"} href="https://www.woodworks.org/publications-media/building-trends-mass-timber/" rel="noopener noreferrer">WoodWorks Wood Product Council</a></h4>
                    <h4>Carbon neutrality - <a target={"_blank"} href="https://www.brplusa.com/codes-and-regulations" rel="noopener noreferrer">BR+A Consulting Engineers</a></h4>
                    <h4>Tall Mass Timber Provisions - <a target={"_blank"} href="https://www.awc.org/codes-standards/code-adoption-map?s=09" rel="noopener noreferrer">American Wood Council</a></h4>
                </div>

            </section>
        </div>

        <Scrollspy
            className="scrollspy"
            items={ ['section-1', 'section-2', 'section-3', 'section-4', 'section-5', 'section-6', 'section-7', 'section-8', 'section-9'] }
            offset={-100}
            currentClassName="isCurrent">
            <li><a href="#section-1">Statewide Inventory</a></li>
            <li><a href="#section-2">Statewide Harvest</a></li>
            <li><a href="#section-3">Monthly Maine Manufacturing<br />Exports by HS Code</a></li>
            <li><a href="#section-4">Monthly Maine International<br />Exports by NACIS Code</a></li>
            <li><a href="#section-5">Energy Costs</a></li>
            <li><a href="#section-6">Investment Incentives</a></li>
            <li><a href="#section-7">Employment and Earnings<br />by MSA and Title</a></li>
            <li><a href="#section-8">Population by County</a></li>
            <li><a href="#section-9">Additional References</a></li>

        </Scrollspy>


    </div>
  );
}