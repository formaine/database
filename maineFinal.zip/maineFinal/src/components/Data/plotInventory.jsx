import React, {useRef, useState, useEffect, setState} from "react";
import Plotly from "plotly.js"

import createPlotlyComponent from 'react-plotly.js/factory';
import {useQuery} from "react-query";
import census from "citysdk";

const Plot = createPlotlyComponent(Plotly);



export const PlotInventory = ({
                            barColorInput,
                            onClick
                        }) => {



    const dataChartNode = useRef();




    const getInventory = () => fetch(`https://raw.githubusercontent.com/eastcoasting/test/master/Inventory.json`);


    function getFavorites() {
        return Promise.all([getInventory()])
            .then(responses => {
                return Promise.all(
                    responses.map(response => {
                        return response.json();
                    })
                );
            })
            .then(data => data);
    }

    const { data } = useQuery('Inventory', getFavorites);



    const [stateXAspen, setStateXAspen] = React.useState([])
    const setDataTableXAspen = [];

    const [stateXSpruceFir, setStateXSpruceFir] = React.useState([])
    const setDataTableXSpruceFir = [];

    const [stateXOtherSoftwood, setStateXOtherSoftwood] = React.useState([])
    const setDataTableXOtherSoftwood = [];

    const [stateXPine, setStateXPine] = React.useState([])
    const setDataTableXPine = [];

    const [stateXCedar, setStateXCedar] = React.useState([])
    const setDataTableXCedar = [];

    const [stateXHardwood, setStateXHardwood] = React.useState([])
    const setDataTableXHardwood = [];


    const [stateYInventory, setStateYInventory] = React.useState([])
    const setDataTableYInventory = [];




    React.useEffect(() => {

        if (!data) {
        } else {
            const [Inventory] = data;

            if (data) {

                for (var key in Inventory) {
                    setDataTableYInventory.push(Inventory[key].Time);
                    setDataTableXAspen.push(Inventory[key]["Aspen Inventory"]);
                    setDataTableXSpruceFir.push(Inventory[key]["Spruce-Fir Inventory"]);
                    setDataTableXOtherSoftwood.push(Inventory[key]["Other Softwood Inventory"]);
                    setDataTableXPine.push(Inventory[key]["Pine Inventory"]);
                    setDataTableXCedar.push(Inventory[key]["Cedar Inventory"]);
                    setDataTableXHardwood.push(Inventory[key]["Hardwood Inventory"]);


                }
                setStateXAspen(setDataTableXAspen);
                setStateXSpruceFir(setDataTableXSpruceFir);
                setStateXOtherSoftwood(setDataTableXOtherSoftwood);
                setStateXPine(setDataTableXPine);
                setStateXCedar(setDataTableXCedar);
                setStateXHardwood(setDataTableXHardwood);



                setStateYInventory(setDataTableYInventory);

            }
        }
    }, [data])






    const chartData = [
        {
            x: stateYInventory,
            y: stateXAspen,
            type: 'bar',
            name: 'Aspen',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s} Tons'

        },
        {
            x: stateYInventory,
            y: stateXSpruceFir,
            type: 'bar',
            name: 'Spruce-Fir',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s} Tons'

        },
        {
            x: stateYInventory,
            y: stateXOtherSoftwood,
            type: 'bar',
            name: 'Other Softwood',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s} Tons'

        },
        {
            x: stateYInventory,
            y: stateXPine,
            type: 'bar',
            name: 'Pine',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s} Tons'

        },{
            x: stateYInventory,
            y: stateXCedar,
            type: 'bar',
            name: 'Cedar',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s} Tons'

        },
        {
            x: stateYInventory,
            y: stateXHardwood,
            type: 'bar',
            name: 'Hardwood',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s} Tons'

        }

    ];




    return (





        <div className={"plotInventory"}
             style={{flexGrow: 1}}>
            <Plot
                style={{width: '75vw', height: '75vh', right: 0}}
                ref={dataChartNode}
                data={chartData}
                layout={{
                    barmode: 'stack',
                    autosize: true,
                    legend: {
                        orientation: "v"
                    },
                    yaxis: {
                        title: "Tons",
                        rangemode: 'tozero'},

                }}
                config={{
                    displaylogo: false,
                    // displayModeBar: true,
                    modeBarButtonsToRemove: [
                        "lasso2d",
                        "autoScale2d", // 2D options
                        "toggleSpikelines",
                        "zoom2d",
                        "zoomIn2d",
                        "zoomOut2d",
                        "pan2d",
                        "hoverClosestCartesian",
                        "hoverCompareCartesian"
                    ],
                    responsive: true,
                    // scrollZoom,
                    showTips: false
                }}
            />
        </div>


    );
}