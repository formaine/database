import React from "react";


import Scroll from './scrollMap';
import App from './scrollMap';

import config from './config';


function About() {
  return (
      <App {...config}/>
  );
}

export default About;