var config = {
    style: 'mapbox://styles/mapbox/satellite-v9',
    accessToken: 'pk.eyJ1Ijoid2lsbGNhcnRlciIsImEiOiJjamV4b2g3Z2ExOGF4MzFwN3R1dHJ3d2J4In0.Ti-hnuBH8W4bHn7k6GCpGw',
    showMarkers: true,
    theme: 'light',
    alignment: 'left',
    title: 'Maine Selected Communities',
    subtitle: 'Between the years 2013-2015, Maine lost paper mills in six different communities. The closures\n' +
        'not only impacted employment, but also community identity and pride, and in many cases\n' +
        'stressed municipal budgets from a sudden drop in the commercial tax base. ',
    /* byline: 'For/Maine',*/
    footer: 'Source: FOR/Maine and Indufor 2020',
    chapters: [
        {
            id: 'millinocket',
            title: 'Millinocket',
            /*image: './path/to/image/source.png',*/
            description: 'Millinocket is nestled in the shadow of Mount Katahdin, Maine’s highest peak and the end point\n' +
                'of the Appalachian Trail. In 1899, prospectors saw the potential of a vast wood basket and the\n' +
                'headwaters of the Penobscot River to make paper. The sister mills of Millinocket and East\n' +
                'Millinocket were wildly prosperous during most of the 20th century. In the 1970s, Millinocket\n' +
                'was considered to have among the highest per-capita income in the state. A number of factors\n' +
                'contributed to the mill’s demise starting in the late ’70s, including labor strikes, a bud worm\n' +
                'epidemic that ravaged wood supply, and environmentalists aggressively targeting dams used for\n' +
                'hydropower. In 1990, Georgia Pacific bought out the assets of Great Northern Paper’s parent\n' +
                'company. Great Northern was sold off almost immediately to Bowater, who tried in earnest to\n' +
                'turn a profit, but Great Northern’s liabilities were too great. Starting in 1999, the mill changed\n' +
                'hands three more times before closing permanently in 2008. The last holding company to own\n' +
                'the mill never started up operations. In 2014, when the great smokestacks over the mill were\n' +
                'demolished, residents knew that paper production was never coming back. In 2017, a community\n' +
                'development nonprofit called Our Katahdin, founded by several ex-pats who loved their\n' +
                'hometown, bought the 1,400 acre site for $1 and assumed its IRS tax liabilities. Currently, a\n' +
                'cross-laminated timber manufacturer of structural building materials has announced intent to\n' +
                'locate on part of the mill site.',
            location: {
                center: [-68.705, 45.6465],
                zoom: 17,
                pitch: 60,
                bearing: -43.2
            },
            onChapterEnter: [],
            onChapterExit: []
        },

        {
            id: 'eastMillinocket',
            title: 'East Millinocket',
            /*image: './path/to/image/source.png',*/
            description: 'The town of East Millinocket is situated between two tributaries at the head of Maine’s Penobscot River. In their heyday, the two sister mills in Millinocket and East Millinocket employed approximately 3,000. Great Northern Paper was bought out in a hostile 1990 takeover by Georgia Pacific, and the mill traded hands several times and sharply declined in production since then. The East Millinocket mill’s last contract was in 2013 before shuttering and laying off the remaining 250 workers. ',
            location: {
                center: [-68.577758, 45.623603],
                zoom: 16,
                pitch: 60,
                bearing: -3.2
            },
            onChapterEnter: [],
            onChapterExit: []
        },
        {
            id: 'lincoln',
            title: 'Lincoln',
            /*image: './path/to/image/source.png',*/
            description: 'Known as the town of thirteen lakes, Lincoln, Maine is situated on the Penobscot River 45\n' +
                'minutes north of the city of Bangor, on Interstate 95. Lincoln is a service center for many of the\n' +
                'rural communities in the northern half of Penobscot County and western Washington County.\n' +
                'Lincoln has a hospital, the regional technical high school, and a big-box retailer. Paper\n' +
                'production first started in the 1880s and the mill changed hands numerous times over the years,\n' +
                'shutting down sporadically due to market conditions and parent company stresses. The mill\n' +
                'directly employed 600 in the 1960s, but only a few hundred in the early days and in more recent\n' +
                'times. The Lincoln Paper & Tissue company filed for Chapter 11 bankruptcy in 2015 after a\n' +
                'boiler explosion two years prior signaled the end of paper production, ending employment for\n' +
                '180 workers. The vacant mill site suffered from some arson damage in 2017. The Town voted to\n' +
                'seek brownfields funding for cleanup of former operations. The Town successfully purchased 77\n' +
                'clean acres of the site in 2018 to repurpose for potential manufacturing tenants. In 2018, Nestle\n' +
                'opened a major spring water extraction facility in Lincoln',
            location: {
                center: [-68.51007, 45.36639],
                zoom: 16,
                pitch: 60,
                bearing: -43.2
            },
            onChapterEnter: [],
            onChapterExit: []
        },
        {
            id: 'oldtown',
            title: 'Old Town',
            /*image: './path/to/image/source.png',*/
            description: 'Old Town is an incorporated city amidst a series of islands in Maine’s Penobscot River situated\n' +
                'on Interstate 95 three towns north of the city of Bangor. Paper and tissue were produced\n' +
                'throughout the 20th century when Georgia Pacific bought the plants in 2000. Old Town has\n' +
                'experienced a series of dramatic fits and starts since then. In 2003, a tissue plant closed, laying\n' +
                'off 300. In late 2004, Koch Industries bought Georgia Pacific and four months later shut down\n' +
                'Old Town operations and its subsidiary suppliers, leaving 459 people without work. A business\n' +
                'coalition bought the mills out of bankruptcy in 2006 but declared bankruptcy itself two years\n' +
                'later. In late 2008, a new venture called Old Town Fuel & Fiber purchased the assets with the\n' +
                'intent of extracting cellulosic sugars from wood fiber, but employment growth and product\n' +
                'development were slow and incremental. Old Town Fuel & Fiber went bankrupt in 2014, laying\n' +
                'off 180 people, and Wisconsin-based Expera purchased the mills to produce pulp for its other\n' +
                'specialty-products facilities. The mill went dark again the next year, and 195 workers lost their\n' +
                'jobs. A liquidation company picked up the assets in the interim before selling to a joint venture\n' +
                'of Maine business interests in 2018, sparing the mill assets from scrap. The University of Maine\n' +
                'also houses its Forest Bioproducts Research Institute Technology Research Center in 40,000\n' +
                'square feet of Old Town mill complex.',
            location: {
                center: [-68.635, 44.918],
                zoom: 17,
                pitch: 60,
                bearing: -43.2
            },
            onChapterEnter: [],
            onChapterExit: []
        },
        {
            id: 'slug-style-id',
            title: 'Ashland',
            /*
                        image: './path/to/image/source.png',
            */
            description: 'Historically a lumber village, in 1993 a biomass (wood processing\n' +
                'waste)-to-electricity boiler plant opened. In 2011 it was acquired by ReEnergy and today\n' +
                'produces enough power for 37,000 homes.',
            location: {
                center: [-68.436202, 46.633860],
                zoom: 17,
                pitch: 60,
                bearing: 0
            },
            onChapterEnter: [
                // {
                //     layer: 'layer-name',
                //     opacity: 1
                // }
            ],
            onChapterExit: [
                // {
                //     layer: 'layer-name',
                //     opacity: 0
                // }
            ]
        }
    ]
};

export default config;