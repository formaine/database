import React, { useState } from "react";
import {PlotMegaregion} from "./Plot/plot";
import {MapboxGLMap} from "./Map/MapboxGLMap"


export const Home = () => {
    const [selectedId, setSelectedId] = useState("");



    const initialFormState = { mySelectKey: 'East' };
    const [myForm, setMyForm] = useState(initialFormState);

    const initialLabelState = { mySelectLabel: "Eastern" };
    const [myLabel, setMyLabel] = useState(initialLabelState);

    const initialFormStateInvHarv = { mySelectKeyInvHarv: 'Inventory' };
    const [myFormInvHarv, setMyFormInvHarv] = useState(initialFormStateInvHarv);

    const initialLabelStateInvHarv = { mySelectLabelInvHarv: "Inventory" };
    const [myLabelInvHarv, setMyLabelInvHarv] = useState(initialLabelStateInvHarv);


    const updateForm = (value, label) => {
        setMyForm({ ...myForm, mySelectKey: value });
        setMyLabel({ ...myLabel, mySelectLabel: label });

    };

    const updateFormInvHarv = (valueInvHarv, labelInvHarv) => {
        setMyFormInvHarv({ ...myFormInvHarv, mySelectKeyInvHarv: valueInvHarv });
        setMyLabelInvHarv({ ...myLabelInvHarv, mySelectLabelInvHarv: labelInvHarv });

    };




  return (
    <div className="home">
      <div className="row">
          <MapboxGLMap
          highlightLineColor={{ rgba: [255, 102, 0, 1] }}
          coordinates={[-119.846, 43.862]}
          zoom={6}
          getSelectedID={() => selectedId}
          />
          <div className="plotly">
              <PlotMegaregion
                  heightP={350}
                  widthP={550}
                  onClickRegion={({ value, label }) => {
                      updateForm(value, label);
                      setSelectedId(label);
                  }}
                  onClickInvHarv={({ valueInvHarv, labelInvHarv }) => {
                      updateFormInvHarv(valueInvHarv, labelInvHarv);
                  }}
                  myLabel={myLabel}
                  myForm={myForm}
                  myLabelInvHarv={myLabelInvHarv}
                  myFormInvHarv={myFormInvHarv}
              />
        </div>
      </div>
    </div>
  );
};
