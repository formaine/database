
import React, {useRef, useState} from "react";
import Plotly from "plotly.js"
import Select from 'react-select'
import Collapsible from 'react-collapsible';
import { AiOutlineLineChart } from 'react-icons/ai';

import createPlotlyComponent from 'react-plotly.js/factory';
import {useQuery} from "react-query";


const Plot = createPlotlyComponent(Plotly);



const customStyles = {
    control: (provided, state) => ({
        ...provided,
        background: '#fff',
        borderColor: '#9e9e9e',
        minHeight: '30px',
        marginBottom: '0px',
        height: '30px',
        width: '150px',
        boxShadow: state.isFocused ? null : null,
    }),

    valueContainer: (provided, state) => ({
        ...provided,
        height: '30px',
        padding: '0 px'
    }),

    input: (provided, state) => ({
        ...provided,
        margin: '0px',
    }),
    indicatorSeparator: state => ({
        display: 'none',
    }),
    indicatorsContainer: (provided, state) => ({
        ...provided,
        height: '30px',
    }),
};


export const PlotMegaregion = ({
                                       heightP,
                                       widthP,
                                       barColorInput,
                                       onClickInvHarv,
                                       onClickRegion,
                                       myForm,
                                       myLabel,
                                       myFormInvHarv,
                                       myLabelInvHarv,

                                   }) => {


    const dataChartNode = useRef();

    const optionsRegion = [
        { value: 'East', label: 'Eastern' },
        { value: 'North', label: 'Northern' },
        { value: 'West', label: 'Western' },
        { value: 'South', label: 'Southern' }
    ];

    const optionsInvHarv = [
        { valueInvHarv: 'Harvest', labelInvHarv: 'Harvest' },
        { valueInvHarv: 'Inventory', labelInvHarv: 'Inventory' }
    ];


    const getRegionInventory = () => fetch(`https://raw.githubusercontent.com/eastcoasting/test/master/${myForm.mySelectKey}${myFormInvHarv.mySelectKeyInvHarv}.json`);

    function getFavorites() {
        return Promise.all([getRegionInventory()])
            .then(responses => {
                return Promise.all(
                    responses.map(response => {
                        return response.json();
                    })
                );
            })
            .then(data => data);
    }

    const { data } = useQuery(`${myForm.mySelectKey}${myFormInvHarv.mySelectKeyInvHarv}`, getFavorites);



    const [stateXAspen, setStateXAspen] = React.useState([])
    const setDataTableXAspen = [];

    const [stateXSpruceFir, setStateXSpruceFir] = React.useState([])
    const setDataTableXSpruceFir = [];

    const [stateXOtherSoftwood, setStateXOtherSoftwood] = React.useState([])
    const setDataTableXOtherSoftwood = [];

    const [stateXPine, setStateXPine] = React.useState([])
    const setDataTableXPine = [];

    const [stateXCedar, setStateXCedar] = React.useState([])
    const setDataTableXCedar = [];

    const [stateXHardwood, setStateXHardwood] = React.useState([])
    const setDataTableXHardwood = [];


    const [stateYInventory, setStateYInventory] = React.useState([])
    const setDataTableYInventory = [];




    React.useEffect(() => {

        if (!data) {
        } else {
            const [Inventory] = data;

            if (data) {

                for (var key in Inventory) {
                    setDataTableYInventory.push(Inventory[key].Time);
                    setDataTableXAspen.push(Inventory[key]["Aspen Inventory"]);
                    setDataTableXSpruceFir.push(Inventory[key]["Spruce-Fir Inventory"]);
                    setDataTableXOtherSoftwood.push(Inventory[key]["Other Softwood Inventory"]);
                    setDataTableXPine.push(Inventory[key]["Pine Inventory"]);
                    setDataTableXCedar.push(Inventory[key]["Cedar Inventory"]);
                    setDataTableXHardwood.push(Inventory[key]["Hardwood Inventory"]);


                }
                setStateXAspen(setDataTableXAspen);
                setStateXSpruceFir(setDataTableXSpruceFir);
                setStateXOtherSoftwood(setDataTableXOtherSoftwood);
                setStateXPine(setDataTableXPine);
                setStateXCedar(setDataTableXCedar);
                setStateXHardwood(setDataTableXHardwood);



                setStateYInventory(setDataTableYInventory);

            }
        }
    }, [data])







    const chartData = [
        {
            x: stateYInventory,
            y: stateXAspen,
            type: 'line',
            name: 'Aspen',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s}'

        },
        {
            x: stateYInventory,
            y: stateXSpruceFir,
            type: 'line',
            name: 'Spruce-Fir',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s}'

        },
        {
            x: stateYInventory,
            y: stateXOtherSoftwood,
            type: 'line',
            name: 'Other Softwood',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s}'

        },
        {
            x: stateYInventory,
            y: stateXPine,
            type: 'line',
            name: 'Pine',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s}'

        },{
            x: stateYInventory,
            y: stateXCedar,
            type: 'line',
            name: 'Cedar',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s}'

        },
        {
            x: stateYInventory,
            y: stateXHardwood,
            type: 'line',
            name: 'Hardwood',
            marker: {color: barColorInput},
            showlegend: true,
            hovertemplate: '%{y:.2s}'

        }

    ];



    return (

        <div className={"plot"} >
            <Collapsible  trigger={<AiOutlineLineChart
                className={'chartIcon'}
                size="40px" />}
                          open ={false}
            >

                <div className={"toggle"} style={{width: '150px', display: 'flex'}}>
                    <Select
                        className={"toggleMegaregion"}
                        styles={customStyles}
                        name="toggleMegaregion"
                        value={optionsRegion.filter(({ value }) => value === myForm.mySelectKey)}
                        getOptionLabel={({ label }) => label}
                        getOptionValue={({ value }) => value}
                        onChange={onClickRegion}
                        options={optionsRegion}
                    />


                    <Select
                        className={"toggleHarvestInventory"}
                        styles={customStyles}
                        name="toggleMegaregion"
                        value={optionsInvHarv.filter(({ valueInvHarv }) => valueInvHarv === myFormInvHarv.mySelectKeyInvHarv)}
                        getOptionLabel={({ labelInvHarv}) => labelInvHarv}
                        getOptionValue={({ valueInvHarv }) => valueInvHarv}
                        onChange={onClickInvHarv}
                        options={optionsInvHarv}
                    />
                </div>



                <Plot
                    ref={dataChartNode}
                    data={chartData}
                    layout={{
                        height: heightP,
                        width: widthP,
                        autosize: true,
                        title: `${myLabel.mySelectLabel} Megaregion ${myFormInvHarv.mySelectKeyInvHarv}`,
                        legend: {
                        orientation: "v"
                    },
                        yaxis: {
                        title: "Tons",
                        rangemode: 'tozero'},

                        }}
                    config={{
                        displaylogo: false,
                        // displayModeBar: true,
                        modeBarButtonsToRemove: [
                            "lasso2d",
                            "autoScale2d", // 2D options
                            "toggleSpikelines",
                            "zoom2d",
                            "zoomIn2d",
                            "zoomOut2d",
                            "pan2d",
                            "hoverClosestCartesian",
                            "hoverCompareCartesian"
                        ],
                        responsive: true,
                        // scrollZoom,
                        showTips: false,
                        toImageButtonOptions: {
                            format: 'svg', // one of png, svg, jpeg, webp
                            filename: 'custom_image',
                            height: 500,
                            width: 700,
                            scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                        }
                    }}
                />
            </Collapsible>
        </div>


    );
}