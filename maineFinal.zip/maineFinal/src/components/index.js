export { default as Navigation } from "./Navigation";
/*
export { default as Footer } from "./Footer";
*/
export { Home } from "./Home/Home";
export { default as About } from "./About";
export { Contact } from "./Data/Contact";
