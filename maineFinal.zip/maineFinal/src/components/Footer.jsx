/*import React from "react";
const logo = require('./logo_white.png')// with require


function Footer() {
  return (
    <div className="footer">
      <footer class="py-2 bg-dark fixed-bottom">
        <div class="container">
            <img src={logo} width="41.05" height="54.25"/>
        </div>
      </footer>
    </div>
  );
}

export default Footer;*/
